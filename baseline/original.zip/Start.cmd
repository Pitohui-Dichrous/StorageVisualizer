@echo off
setlocal
cd /d "%~dp0"
set "SCRIPT=%~dp0DiskSpaceVisualizer.ps1"
set "LOG=%~dp0DiskSpaceVisualizer_error.log"
if exist "%LOG%" del "%LOG%" >nul 2>nul
if not exist "%SCRIPT%" (
  echo DiskSpaceVisualizer.ps1 was not found.
  echo Please extract the zip file completely before running Start.cmd.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%SCRIPT%" 1>"%~dp0DiskSpaceVisualizer_stdout.log" 2>"%LOG%"
set "EC=%ERRORLEVEL%"
if not "%EC%"=="0" (
  echo Program exited with error code %EC%.
  echo Error log: %LOG%
  type "%LOG%"
  pause
)
exit /b %EC%
