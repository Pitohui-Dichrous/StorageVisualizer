Portable Disk Space Visualizer v5

How to run:
1. Extract the zip file completely.
2. Open the extracted folder.
3. Double-click Start.cmd.

If Start.cmd fails:
- Double-click Start_Diagnostic.cmd.
- Or open DiskSpaceVisualizer_error.log and send the content for troubleshooting.

What it does:
- Scans selected directories or all fixed drives.
- Shows folder size, percentage, file count, folder count, modified time, and full path.
- Double-click a row or click Drill down to scan inside that folder.
- Exports results to CSV.

Safety:
- Read-only scanner.
- It does not delete files.
- It does not write registry keys.
- Reparse points are skipped to avoid junction/symlink loops.

Compatibility:
- Windows 10 / Windows 11.
- Windows PowerShell 5.1.
