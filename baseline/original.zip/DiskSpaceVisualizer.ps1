# DiskSpaceVisualizer.ps1
# Portable disk space visualizer for Windows PowerShell 5.1.
# ASCII-only source to avoid Windows PowerShell 5.1 encoding issues.

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

$script:StopRequested = $false
$script:Rows = @()
$script:CurrentTotalBytes = [Int64]0
$script:LastUiUpdate = Get-Date

function Repeat-Text {
    param(
        [string]$Text,
        [int]$Count
    )
    if ($Count -le 0) { return '' }
    return ($Text * $Count)
}

function Format-Bytes {
    param([Int64]$Bytes)
    $value = [double]$Bytes
    $units = @('B','KB','MB','GB','TB','PB')
    $index = 0
    while ($value -ge 1024 -and $index -lt ($units.Count - 1)) {
        $value = $value / 1024
        $index++
    }
    if ($index -eq 0) { return ('{0:N0} {1}' -f $value, $units[$index]) }
    return ('{0:N2} {1}' -f $value, $units[$index])
}

function Format-Percent {
    param([double]$Value)
    return ('{0:N2}%' -f $Value)
}

function Make-Bar {
    param([double]$Percent)
    if ($Percent -lt 0) { $Percent = 0 }
    if ($Percent -gt 100) { $Percent = 100 }
    $width = 20
    $filled = [int][Math]::Round(($Percent / 100.0) * $width)
    if ($filled -lt 0) { $filled = 0 }
    if ($filled -gt $width) { $filled = $width }
    $empty = $width - $filled
    return ('[{0}{1}] {2:N1}%' -f (Repeat-Text '#' $filled), (Repeat-Text '.' $empty), $Percent)
}

function Safe-DateText {
    param([datetime]$DateValue)
    if ($DateValue -eq [datetime]::MinValue) { return '' }
    return $DateValue.ToString('yyyy-MM-dd HH:mm:ss')
}

function Update-Ui {
    param(
        [string]$Text,
        [int]$Progress = -1,
        [bool]$Force = $false
    )
    $now = Get-Date
    if (-not $Force -and (($now - $script:LastUiUpdate).TotalMilliseconds -lt 200)) {
        return
    }
    $script:LastUiUpdate = $now
    if ($null -ne $script:StatusLabel -and $Text -ne $null) {
        $script:StatusLabel.Text = $Text
    }
    if ($null -ne $script:ProgressBar -and $Progress -ge 0) {
        if ($Progress -gt 100) { $Progress = 100 }
        if ($Progress -lt 0) { $Progress = 0 }
        $script:ProgressBar.Value = $Progress
    }
    [System.Windows.Forms.Application]::DoEvents()
}

function Is-ReparsePoint {
    param([System.IO.FileSystemInfo]$Item)
    try {
        return (($Item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0)
    } catch {
        return $true
    }
}

function New-StatsObject {
    param(
        [Int64]$SizeBytes = 0,
        [Int64]$FileCount = 0,
        [Int64]$FolderCount = 0,
        [datetime]$LatestWrite = ([datetime]::MinValue),
        [Int64]$ErrorCount = 0
    )
    return [pscustomobject]@{
        SizeBytes = $SizeBytes
        FileCount = $FileCount
        FolderCount = $FolderCount
        LatestWrite = $LatestWrite
        ErrorCount = $ErrorCount
    }
}

function Measure-DirectoryTree {
    param([string]$RootPath)

    [Int64]$sizeBytes = 0
    [Int64]$fileCount = 0
    [Int64]$folderCount = 0
    [Int64]$errorCount = 0
    [datetime]$latestWrite = [datetime]::MinValue
    [Int64]$visited = 0

    $stack = New-Object System.Collections.Stack
    $stack.Push($RootPath)

    while ($stack.Count -gt 0) {
        if ($script:StopRequested) { break }
        $current = [string]$stack.Pop()
        $visited++

        if (($visited % 50) -eq 0) {
            Update-Ui -Text ('Scanning: {0}' -f $current)
        }

        try {
            $di = New-Object System.IO.DirectoryInfo($current)
            if (-not $di.Exists) { continue }

            try {
                foreach ($file in $di.EnumerateFiles()) {
                    if ($script:StopRequested) { break }
                    try {
                        if (Is-ReparsePoint $file) { continue }
                        $fileCount++
                        $sizeBytes += [Int64]$file.Length
                        if ($file.LastWriteTime -gt $latestWrite) { $latestWrite = $file.LastWriteTime }
                    } catch {
                        $errorCount++
                    }
                }
            } catch {
                $errorCount++
            }

            try {
                foreach ($subDir in $di.EnumerateDirectories()) {
                    if ($script:StopRequested) { break }
                    try {
                        if (Is-ReparsePoint $subDir) { continue }
                        $folderCount++
                        if ($subDir.LastWriteTime -gt $latestWrite) { $latestWrite = $subDir.LastWriteTime }
                        $stack.Push($subDir.FullName)
                    } catch {
                        $errorCount++
                    }
                }
            } catch {
                $errorCount++
            }
        } catch {
            $errorCount++
        }
    }

    return (New-StatsObject -SizeBytes $sizeBytes -FileCount $fileCount -FolderCount $folderCount -LatestWrite $latestWrite -ErrorCount $errorCount)
}

function Measure-DirectFiles {
    param([string]$RootPath)

    [Int64]$sizeBytes = 0
    [Int64]$fileCount = 0
    [datetime]$latestWrite = [datetime]::MinValue
    [Int64]$errorCount = 0

    try {
        $di = New-Object System.IO.DirectoryInfo($RootPath)
        foreach ($file in $di.EnumerateFiles()) {
            try {
                if (Is-ReparsePoint $file) { continue }
                $fileCount++
                $sizeBytes += [Int64]$file.Length
                if ($file.LastWriteTime -gt $latestWrite) { $latestWrite = $file.LastWriteTime }
            } catch {
                $errorCount++
            }
        }
    } catch {
        $errorCount++
    }

    return (New-StatsObject -SizeBytes $sizeBytes -FileCount $fileCount -FolderCount 0 -LatestWrite $latestWrite -ErrorCount $errorCount)
}

function Add-ResultRow {
    param(
        [string]$Name,
        [string]$Type,
        [string]$Path,
        [object]$Stats
    )

    $script:Rows += [pscustomobject]@{
        Name = $Name
        Type = $Type
        Path = $Path
        SizeBytes = [Int64]$Stats.SizeBytes
        FileCount = [Int64]$Stats.FileCount
        FolderCount = [Int64]$Stats.FolderCount
        LatestWrite = $Stats.LatestWrite
        ErrorCount = [Int64]$Stats.ErrorCount
    }
}

function Parse-InputPaths {
    param([string]$Text)
    $items = @()
    foreach ($raw in ($Text -split "[;`r`n]+")) {
        $p = $raw.Trim()
        if ($p.StartsWith('"') -and $p.EndsWith('"') -and $p.Length -ge 2) {
            $p = $p.Substring(1, $p.Length - 2)
        }
        if ($p.Length -gt 0) { $items += $p }
    }
    return $items
}

function Measure-OneRoot {
    param([string]$RootPath)

    if (-not (Test-Path -LiteralPath $RootPath -PathType Container)) {
        Add-ResultRow -Name ('Invalid path: {0}' -f $RootPath) -Type 'Error' -Path $RootPath -Stats (New-StatsObject -ErrorCount 1)
        return
    }

    $rootFull = (New-Object System.IO.DirectoryInfo($RootPath)).FullName
    Update-Ui -Text ('Listing: {0}' -f $rootFull) -Force $true

    $directFiles = Measure-DirectFiles -RootPath $rootFull
    if ($directFiles.SizeBytes -gt 0 -or $directFiles.FileCount -gt 0) {
        Add-ResultRow -Name '[files directly in this folder]' -Type 'Files' -Path $rootFull -Stats $directFiles
    }

    $dirs = @()
    try {
        $rootInfo = New-Object System.IO.DirectoryInfo($rootFull)
        foreach ($dir in $rootInfo.EnumerateDirectories()) {
            if ($script:StopRequested) { break }
            try {
                if (Is-ReparsePoint $dir) { continue }
                $dirs += $dir
            } catch {
                Add-ResultRow -Name $dir.Name -Type 'Error' -Path $dir.FullName -Stats (New-StatsObject -ErrorCount 1)
            }
        }
    } catch {
        Add-ResultRow -Name ('Cannot list: {0}' -f $rootFull) -Type 'Error' -Path $rootFull -Stats (New-StatsObject -ErrorCount 1)
        return
    }

    $totalDirs = [Math]::Max(1, $dirs.Count)
    $index = 0
    foreach ($dir in $dirs) {
        if ($script:StopRequested) { break }
        $index++
        $percent = [int](($index / [double]$totalDirs) * 100)
        Update-Ui -Text ('Scanning {0} of {1}: {2}' -f $index, $totalDirs, $dir.FullName) -Progress $percent -Force $true
        $stats = Measure-DirectoryTree -RootPath $dir.FullName
        Add-ResultRow -Name $dir.Name -Type 'Folder' -Path $dir.FullName -Stats $stats
    }
}

function Refresh-Grid {
    $total = [Int64]0
    foreach ($r in $script:Rows) { $total += [Int64]$r.SizeBytes }
    $script:CurrentTotalBytes = $total

    $dt = New-Object System.Data.DataTable
    [void]$dt.Columns.Add('Name', [string])
    [void]$dt.Columns.Add('Type', [string])
    [void]$dt.Columns.Add('Size', [string])
    [void]$dt.Columns.Add('Percent', [string])
    [void]$dt.Columns.Add('Bar', [string])
    [void]$dt.Columns.Add('Files', [Int64])
    [void]$dt.Columns.Add('Folders', [Int64])
    [void]$dt.Columns.Add('Errors', [Int64])
    [void]$dt.Columns.Add('Modified', [string])
    [void]$dt.Columns.Add('Path', [string])
    [void]$dt.Columns.Add('SizeBytes', [Int64])

    foreach ($r in ($script:Rows | Sort-Object SizeBytes -Descending)) {
        $pct = 0.0
        if ($total -gt 0) { $pct = ([double]$r.SizeBytes / [double]$total) * 100.0 }
        $dr = $dt.NewRow()
        $dr['Name'] = [string]$r.Name
        $dr['Type'] = [string]$r.Type
        $dr['Size'] = Format-Bytes ([Int64]$r.SizeBytes)
        $dr['Percent'] = Format-Percent $pct
        $dr['Bar'] = Make-Bar $pct
        $dr['Files'] = [Int64]$r.FileCount
        $dr['Folders'] = [Int64]$r.FolderCount
        $dr['Errors'] = [Int64]$r.ErrorCount
        $dr['Modified'] = Safe-DateText $r.LatestWrite
        $dr['Path'] = [string]$r.Path
        $dr['SizeBytes'] = [Int64]$r.SizeBytes
        [void]$dt.Rows.Add($dr)
    }

    $script:Grid.DataSource = $dt
    try { $script:Grid.Columns['SizeBytes'].Visible = $false } catch { }
    try { $script:Grid.Columns['Path'].Width = 360 } catch { }
    try { $script:Grid.Columns['Name'].Width = 220 } catch { }
    try { $script:Grid.Columns['Bar'].Width = 180 } catch { }
    try { $script:Grid.Columns['Size'].Width = 100 } catch { }
    try { $script:Grid.Columns['Percent'].Width = 80 } catch { }

    Update-Ui -Text ('Done. Total scanned size: {0}. Rows: {1}' -f (Format-Bytes $total), $script:Rows.Count) -Progress 100 -Force $true
}

function Set-ButtonsBusy {
    param([bool]$Busy)
    $script:BtnChoose.Enabled = -not $Busy
    $script:BtnScanCurrent.Enabled = -not $Busy
    $script:BtnScanDrives.Enabled = -not $Busy
    $script:BtnDown.Enabled = -not $Busy
    $script:BtnOpen.Enabled = -not $Busy
    $script:BtnExport.Enabled = -not $Busy
    $script:BtnStop.Enabled = $Busy
}

function Start-ScanPaths {
    param([string[]]$Paths)

    $script:StopRequested = $false
    $script:Rows = @()
    $script:ProgressBar.Value = 0
    Set-ButtonsBusy $true

    try {
        if ($Paths.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show('No directory path specified.', 'Input required', 'OK', 'Information') | Out-Null
            return
        }
        foreach ($p in $Paths) {
            if ($script:StopRequested) { break }
            Measure-OneRoot -RootPath $p
        }
        Refresh-Grid
        if ($script:StopRequested) {
            Update-Ui -Text ('Stopped. Partial result total: {0}' -f (Format-Bytes $script:CurrentTotalBytes)) -Force $true
        }
    } catch {
        $msg = $_.Exception.ToString()
        Update-Ui -Text ('Scan failed: {0}' -f $_.Exception.Message) -Force $true
        [System.Windows.Forms.MessageBox]::Show($msg, 'Scan failed', 'OK', 'Error') | Out-Null
    } finally {
        Set-ButtonsBusy $false
    }
}

function Get-SelectedPath {
    try {
        if ($script:Grid.SelectedRows.Count -gt 0) {
            return [string]$script:Grid.SelectedRows[0].Cells['Path'].Value
        }
        if ($script:Grid.CurrentRow -ne $null) {
            return [string]$script:Grid.CurrentRow.Cells['Path'].Value
        }
    } catch { }
    return ''
}

function Down-IntoSelected {
    $p = Get-SelectedPath
    if ($p.Length -eq 0) { return }
    if (Test-Path -LiteralPath $p -PathType Container) {
        $script:PathBox.Text = $p
        Start-ScanPaths @($p)
    } else {
        [System.Windows.Forms.MessageBox]::Show('The selected row is not a directory.', 'Cannot open', 'OK', 'Information') | Out-Null
    }
}

function Open-SelectedPath {
    $p = Get-SelectedPath
    if ($p.Length -eq 0) { return }
    if (Test-Path -LiteralPath $p) {
        Start-Process explorer.exe -ArgumentList ('/select,"{0}"' -f $p)
    } else {
        [System.Windows.Forms.MessageBox]::Show('Path does not exist.', 'Cannot open', 'OK', 'Information') | Out-Null
    }
}

function Export-Results {
    if ($script:Rows.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('No scan result to export.', 'Export CSV', 'OK', 'Information') | Out-Null
        return
    }
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.Filter = 'CSV files (*.csv)|*.csv|All files (*.*)|*.*'
    $dlg.FileName = ('disk-space-{0}.csv' -f (Get-Date).ToString('yyyyMMdd-HHmmss'))
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $total = [Math]::Max(1, [double]$script:CurrentTotalBytes)
        $exportRows = foreach ($r in ($script:Rows | Sort-Object SizeBytes -Descending)) {
            [pscustomobject]@{
                Name = $r.Name
                Type = $r.Type
                SizeBytes = $r.SizeBytes
                Size = (Format-Bytes ([Int64]$r.SizeBytes))
                Percent = ('{0:N4}' -f (([double]$r.SizeBytes / $total) * 100.0))
                Files = $r.FileCount
                Folders = $r.FolderCount
                Errors = $r.ErrorCount
                Modified = (Safe-DateText $r.LatestWrite)
                Path = $r.Path
            }
        }
        $exportRows | Export-Csv -LiteralPath $dlg.FileName -NoTypeInformation -Encoding UTF8
        [System.Windows.Forms.MessageBox]::Show(('Exported: {0}' -f $dlg.FileName), 'Export CSV', 'OK', 'Information') | Out-Null
    }
}

# Build UI
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Portable Disk Space Visualizer'
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(1180, 720)
$form.MinimumSize = New-Object System.Drawing.Size(900, 560)

$label = New-Object System.Windows.Forms.Label
$label.Text = 'Scan directories. Separate multiple paths with semicolons or new lines.'
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(10, 10)
$form.Controls.Add($label)

$pathBox = New-Object System.Windows.Forms.TextBox
$pathBox.Location = New-Object System.Drawing.Point(10, 36)
$pathBox.Size = New-Object System.Drawing.Size(760, 24)
$pathBox.Anchor = 'Top,Left,Right'
try { $pathBox.Text = [Environment]::GetFolderPath('Desktop') } catch { $pathBox.Text = $env:USERPROFILE }
$form.Controls.Add($pathBox)
$script:PathBox = $pathBox

$btnChoose = New-Object System.Windows.Forms.Button
$btnChoose.Text = 'Choose folder'
$btnChoose.Location = New-Object System.Drawing.Point(785, 34)
$btnChoose.Size = New-Object System.Drawing.Size(110, 30)
$btnChoose.Anchor = 'Top,Right'
$form.Controls.Add($btnChoose)
$script:BtnChoose = $btnChoose

$btnScanCurrent = New-Object System.Windows.Forms.Button
$btnScanCurrent.Text = 'Scan current'
$btnScanCurrent.Location = New-Object System.Drawing.Point(905, 34)
$btnScanCurrent.Size = New-Object System.Drawing.Size(110, 30)
$btnScanCurrent.Anchor = 'Top,Right'
$form.Controls.Add($btnScanCurrent)
$script:BtnScanCurrent = $btnScanCurrent

$btnScanDrives = New-Object System.Windows.Forms.Button
$btnScanDrives.Text = 'Scan fixed drives'
$btnScanDrives.Location = New-Object System.Drawing.Point(1025, 34)
$btnScanDrives.Size = New-Object System.Drawing.Size(130, 30)
$btnScanDrives.Anchor = 'Top,Right'
$form.Controls.Add($btnScanDrives)
$script:BtnScanDrives = $btnScanDrives

$btnStop = New-Object System.Windows.Forms.Button
$btnStop.Text = 'Stop'
$btnStop.Location = New-Object System.Drawing.Point(10, 76)
$btnStop.Size = New-Object System.Drawing.Size(80, 30)
$btnStop.Enabled = $false
$form.Controls.Add($btnStop)
$script:BtnStop = $btnStop

$btnDown = New-Object System.Windows.Forms.Button
$btnDown.Text = 'Drill down'
$btnDown.Location = New-Object System.Drawing.Point(100, 76)
$btnDown.Size = New-Object System.Drawing.Size(100, 30)
$form.Controls.Add($btnDown)
$script:BtnDown = $btnDown

$btnOpen = New-Object System.Windows.Forms.Button
$btnOpen.Text = 'Open path'
$btnOpen.Location = New-Object System.Drawing.Point(210, 76)
$btnOpen.Size = New-Object System.Drawing.Size(100, 30)
$form.Controls.Add($btnOpen)
$script:BtnOpen = $btnOpen

$btnExport = New-Object System.Windows.Forms.Button
$btnExport.Text = 'Export CSV'
$btnExport.Location = New-Object System.Drawing.Point(320, 76)
$btnExport.Size = New-Object System.Drawing.Size(100, 30)
$form.Controls.Add($btnExport)
$script:BtnExport = $btnExport

$hint = New-Object System.Windows.Forms.Label
$hint.Text = 'Read-only scanner. Reparse points are skipped to avoid junction loops. No files are deleted.'
$hint.AutoSize = $true
$hint.Location = New-Object System.Drawing.Point(440, 83)
$hint.Anchor = 'Top,Left'
$form.Controls.Add($hint)

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location = New-Object System.Drawing.Point(10, 120)
$grid.Size = New-Object System.Drawing.Size(1145, 500)
$grid.Anchor = 'Top,Bottom,Left,Right'
$grid.ReadOnly = $true
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.MultiSelect = $false
$grid.AutoSizeColumnsMode = 'None'
$grid.RowHeadersVisible = $false
$form.Controls.Add($grid)
$script:Grid = $grid

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Location = New-Object System.Drawing.Point(10, 635)
$progress.Size = New-Object System.Drawing.Size(250, 18)
$progress.Anchor = 'Bottom,Left'
$form.Controls.Add($progress)
$script:ProgressBar = $progress

$status = New-Object System.Windows.Forms.Label
$status.Text = 'Ready.'
$status.Location = New-Object System.Drawing.Point(270, 632)
$status.Size = New-Object System.Drawing.Size(885, 40)
$status.Anchor = 'Bottom,Left,Right'
$form.Controls.Add($status)
$script:StatusLabel = $status

$btnChoose.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    if (Test-Path -LiteralPath $script:PathBox.Text -PathType Container) {
        $dlg.SelectedPath = $script:PathBox.Text
    }
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $script:PathBox.Text = $dlg.SelectedPath
    }
})

$btnScanCurrent.Add_Click({
    $paths = Parse-InputPaths $script:PathBox.Text
    Start-ScanPaths $paths
})

$btnScanDrives.Add_Click({
    $drives = @()
    foreach ($d in [System.IO.DriveInfo]::GetDrives()) {
        try {
            if ($d.DriveType -eq [System.IO.DriveType]::Fixed -and $d.IsReady) {
                $drives += $d.RootDirectory.FullName
            }
        } catch { }
    }
    if ($drives.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('No fixed drive found.', 'Scan fixed drives', 'OK', 'Information') | Out-Null
    } else {
        $script:PathBox.Text = ($drives -join ';')
        Start-ScanPaths $drives
    }
})

$btnStop.Add_Click({
    $script:StopRequested = $true
    Update-Ui -Text 'Stopping. Waiting for current directory operation to finish...' -Force $true
})

$btnDown.Add_Click({ Down-IntoSelected })
$btnOpen.Add_Click({ Open-SelectedPath })
$btnExport.Add_Click({ Export-Results })
$grid.Add_CellDoubleClick({ Down-IntoSelected })

[void]$form.ShowDialog()
