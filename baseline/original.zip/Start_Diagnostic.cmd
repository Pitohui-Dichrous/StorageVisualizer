@echo off
setlocal
cd /d "%~dp0"
set "SCRIPT=%~dp0DiskSpaceVisualizer.ps1"
if not exist "%SCRIPT%" (
  echo DiskSpaceVisualizer.ps1 was not found.
  echo Please extract the zip file completely before running Start_Diagnostic.cmd.
  pause
  exit /b 1
)
echo Running diagnostic mode...
echo Script: %SCRIPT%
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -NoExit -File "%SCRIPT%"
